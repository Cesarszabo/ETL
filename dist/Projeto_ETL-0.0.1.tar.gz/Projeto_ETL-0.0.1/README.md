# Projeto_ETL

## Descrição. 
    Código para extração e limpeza de dados a partir de um arquivo.
    A limpeza é feita sobre os dados nulos e a transformação através de filtros.  
    O objetivo é a saída de um banco de dados personalizado conforme a necessidade do usuário.   

